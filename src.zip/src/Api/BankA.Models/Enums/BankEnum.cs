﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankA.Models.Enums
{
   public enum BankEnum
    {
        HSBC,
        LLOYDS,
        NATWEST
    }
}
