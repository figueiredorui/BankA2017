﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BankA.Services.Files;

namespace BankA.Tests.Services
{
    [TestClass]
    public class StatementFileServiceTest
    {
        [TestMethod]
        public void GetBankTest()
        {
            var svc = new FilesService();
            //svc.GetStatementMap(1);

        }
    }
}
