﻿CREATE TABLE [dbo].[BankVersion] (
    [Version] NVARCHAR (50) NOT NULL,
    CONSTRAINT [PK_BankVersion] PRIMARY KEY CLUSTERED ([Version] ASC)
);

