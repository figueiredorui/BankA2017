

# prerequisites


## .NET 4.5.1

[Microsoft .NET Framework 4.5.1](https://download.microsoft.com/download/1/6/7/167F0D79-9317-48AE-AEDB-17120579F8E2/NDP451-KB2858728-x86-x64-AllOS-ENU.exe)

[Microsoft Build Tools 2013](https://download.microsoft.com/download/9/B/B/9BB1309E-1A8F-4A47-A6C5-ECF76672A3B3/BuildTools_Full.exe)

## npm

The best way to install npm is to install node using the node.js installer https://nodejs.org. npm is installed as part of node.


# building

```
git clone https://github.com/figueiredorui/BankA.git
cd banka\src
build.bat
```
